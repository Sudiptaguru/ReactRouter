import React from 'react'
export const UserDetails = () => {
    return (
        <div>Details About User</div>
    )
}