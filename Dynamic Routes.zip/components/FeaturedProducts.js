export const FeaturedProducts = () => {
    return (
        <div>
            List of featured products
        </div>
    )
}