import React from 'react'
export const Admin = () => {
    return (
        <div>Admin user</div>
    )
}