export const NewProducts = () => {
    return (
        <div>
            List of new nroducts
        </div>
    )
}