export const NewProducts = () => {
    return (
        <div>
            List of new products
        </div>
    )
}