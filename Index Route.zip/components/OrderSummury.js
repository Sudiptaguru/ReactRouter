import { useNavigate } from 'react-router-dom'

export const OrderSummury = () => {
    const navigate = useNavigate()
    return (
        <>
           <div>Order confirmed!</div>
           <button onClick={() => navigate(-1)}>Go Back</button>
        </>
    )
}